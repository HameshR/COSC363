/*==================================================================================
* COSC 363  Computer Graphics (2020)
* Department of Computer Science and Software Engineering, University of Canterbury.
*
* Assignment 2 - Ray Tracing
* Author: Hamesh Ravji
*===================================================================================
*/
#include <iostream>
#include <cmath>
#include <vector>
#include <glm/glm.hpp>
#include "Sphere.h"
#include "SceneObject.h"
#include "Ray.h"
#include <GL/freeglut.h>
#include "Plane.h"
#include "Cylinder.h"
#include "Cone.h"
#include "TextureBMP.h"
using namespace std;

const float WIDTH = 20.0;  
const float HEIGHT = 20.0;
const float EDIST = 40.0;
const int NUMDIV = 500;
const int MAX_STEPS = 5;
const float XMIN = -WIDTH * 0.5;
const float XMAX =  WIDTH * 0.5;
const float YMIN = -HEIGHT * 0.5;
const float YMAX =  HEIGHT * 0.5;
const int SS_L = 4;

vector<SceneObject*> sceneObjects;
TextureBMP texture;


//---The most important function in a ray tracer! ---------------------------------- 
//   Computes the colour value obtained by tracing a ray and finding its 
//     closest point of intersection with objects in the scene.
//----------------------------------------------------------------------------------
glm::vec3 trace(Ray ray, int step)
{
	glm::vec3 backgroundCol(1);						//Background colour = (0,0,0)
	glm::vec3 lightPos(10, 40, -3);					//Light's position
	glm::vec3 lightPos2(-10, 40, -3);
	glm::vec3 color(0);
	SceneObject* obj;

    ray.closestPt(sceneObjects);					//Compare the ray with all objects in the scene
    if(ray.index == -1) return backgroundCol;		//no intersection
	obj = sceneObjects[ray.index];					//object on which the closest point of intersection is found
	
	if (ray.index == 4																																																																																																								)
	{
		//chequered pattern
		int stripeWidthZ = 5;
		int stripeWidthX = 5;
		int iz = (ray.hit.z) / stripeWidthZ;
		int ix = (ray.hit.x + 50) / stripeWidthX;
		int l = ix % 2;
		int k = iz % 2;
		if ((l && k) || (!l && !k)) color = glm::vec3(1, 135.0/255.0, 67.0/255.0); // orange
		else color = glm::vec3(67.0/255.0, 177.0/255.0, 1); // blue
		obj->setColor(color);
	}
	
	if (ray.index == 5)
	{
		//random non-chequered pattern
		float amp = 0.4;
		float ix = ((ray.hit.x + 50) * M_PI)/20;
		float hity = abs(ray.hit.y);
		float checky = fmod(hity, 20);
		if (checky < 20) ix += M_PI;
		float iy = amp * cos(ix) + amp;
		if (fmod(iy, (amp * 2)) < fmod(hity, (amp * 2))) color = glm::vec3(1, 135.0/255.0, 67.0/255.0); // orange
		else color = glm::vec3(67.0/255.0, 177.0/255.0, 1); // blue
		obj->setColor(color);
	}
    
    if (ray.index == 6)
    {
        glm::vec3 n = obj->normal(ray.hit);
        double tu = asin(n.x)/M_PI + 0.5;
        double tv = asin(n.y)/M_PI + 0.5;
        obj->setColor(texture.getColorAt(tu, tv));
    }

	color = obj->lighting(lightPos, -ray.dir, ray.hit);		//Object's colour
	glm::vec3 lightVec = lightPos - ray.hit;
	Ray shadowRay(ray.hit, lightVec);
	shadowRay.closestPt(sceneObjects);
	
	if ((shadowRay.index > -1) && (shadowRay.dist < glm::length(lightVec))) 
	{
		if (sceneObjects[shadowRay.index]->isTransparent() || 
			sceneObjects[shadowRay.index]->isRefractive()) {
			color = 0.7f*obj->getColor();
		} else {
			color = 0.2f*obj->getColor();	//0.2=ambient scale factor
		}
	}
	
	if (obj->isReflective() && step < MAX_STEPS)
	{
		float rho = obj->getReflectionCoeff();
		glm::vec3 normalVec = obj->normal(ray.hit);
		glm::vec3 reflectedDir = glm::reflect(ray.dir, normalVec);
		Ray reflectedRay(ray.hit, reflectedDir);
		glm::vec3 reflectedColor = trace(reflectedRay, step + 1);
		color = color + (rho * reflectedColor);
	}
	
	if (obj->isTransparent() && step < MAX_STEPS)
	{
		Ray transparentRay(ray.hit, ray.dir);
		glm::vec3 transparentCol = trace(transparentRay, 1);
		color = color + (0.9f * transparentCol);
	}
	
	if (obj->isRefractive() && step < MAX_STEPS)
	{
		float eta = 1/obj->getRefractiveIndex();
		glm::vec3 n = obj->normal(ray.hit);
		glm::vec3 g = glm::refract(ray.dir, n, eta);
		Ray refrRay1(ray.hit, g);
		refrRay1.closestPt(sceneObjects);
		
		glm::vec3 m = obj->normal(refrRay1.hit);
		glm::vec3 h = glm::refract(g, -m, 1.0f/eta);
		Ray refrRay2(refrRay1.hit, h);
		
		glm::vec3 refrCol = trace(refrRay2, step+1);
		color = color + obj->getRefractionCoeff() * refrCol;
	}
	
	if (ray.index >= 7 && ray.index <= 12)
	{
		obj->setColor(glm::vec3(1, 0, 1));
	}
	
	if (ray.index == 13) obj->setColor(glm::vec3(165.0/255, 42.0/255.0, 42.0/255.0));
	
	if (ray.index == 14) obj->setColor(glm::vec3(0, 1, 0));
	
	float t = (ray.hit.z +50)/(-400+50);
	color = (1-t)*color + t*backgroundCol;
	
	return color;
}

//---The main display module -----------------------------------------------------------
// In a ray tracing application, it just displays the ray traced image by drawing
// each cell as a quad.
//---------------------------------------------------------------------------------------
void display()
{
	float xp, yp;  //grid point
	float cellX = (XMAX-XMIN)/NUMDIV;  //cell width
	float cellY = (YMAX-YMIN)/NUMDIV;  //cell height
	glm::vec3 eye(0., 0., 0.);

	glClear(GL_COLOR_BUFFER_BIT);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

	glBegin(GL_QUADS);  //Each cell is a tiny quad.

	for (int i = 0; i < NUMDIV; i++)	//Scan every cell of the image plane
	{
		xp = XMIN + i*cellX;
		for (int j = 0; j < NUMDIV; j++)
		{
			yp = YMIN + j*cellY;
			            
            //anti-aliasing (super-sampling)
            
            glm::vec3 col(0);
            
            float dx = cellX / SS_L;
			float dy = cellY / SS_L;
            
            float cx = xp + 0.5*dx;
			float cy = yp + 0.5*dy;

			for (int k = 0; k < SS_L; k++) {
				for (int l = 0; l < SS_L; l++) {
					glm::vec3 dir(cx + k * dx, cy + l * dy, -EDIST);
					Ray ray = Ray(eye, dir);
					col += trace(ray, 1);
				}
			}
			
			//get color average
			
			col /= SS_L * SS_L;
            
			glColor3f(col.r, col.g, col.b);
			glVertex2f(xp, yp);				//Draw each cell with its color value
			glVertex2f(xp+cellX, yp);
			glVertex2f(xp+cellX, yp+cellY);
			glVertex2f(xp, yp+cellY);
        }
    }

    glEnd();
    glFlush();
}



//---This function initializes the scene ------------------------------------------- 
//   Specifically, it creates scene objects (spheres, planes, cones, cylinders etc)
//     and add them to the list of scene objects.
//   It also initializes the OpenGL orthographc projection matrix for drawing the
//     the ray traced image.
//----------------------------------------------------------------------------------
void initialize()
{
    glMatrixMode(GL_PROJECTION);
    gluOrtho2D(XMIN, XMAX, YMIN, YMAX);
    texture = TextureBMP("sphere_tex.bmp");

    glClearColor(0, 0, 0, 1);

	//standard reflective sphere
	Sphere *sphere1 = new Sphere(glm::vec3(-5.0, 0.0, -200.0), 15.0);
	sphere1->setColor(glm::vec3(0, 0, 1));   //Set colour to blue
	sceneObjects.push_back(sphere1);		 //Add sphere to scene objects
	sphere1->setReflectivity(true, 0.5);

	//transparent sphere
	Sphere *sphere2 = new Sphere(glm::vec3(5.0, -11.0, -70.0), 4.0);
	sphere2->setColor(glm::vec3(0, 0, 0));   
	sceneObjects.push_back(sphere2);		 //Add sphere to scene objects
	sphere2->setTransparency(true);
    sphere2->setReflectivity(true, 0.001);
	
	//refractive/reflective sphere
	Sphere *sphere3 = new Sphere(glm::vec3(-15.0, -6.0, -95.0), 4.0);
	sphere3->setColor(glm::vec3(0, 0, 0));   
	sceneObjects.push_back(sphere3);		 //Add sphere to scene objects
	sphere3->setReflectivity(true, 0.3);
	sphere3->setRefractivity(true, 0.8, 1.003);
	
	//standard light blue sphere
	Sphere *sphere4 = new Sphere(glm::vec3(17.0, 10.0, -150.0), 6.0);
    sphere4->setColor(glm::vec3(0, 1, 1));   //Set Colour to light blue
	sceneObjects.push_back(sphere4);		 //Add sphere to scene objects
	
	//chequered floor
	Plane *plane = new Plane (glm::vec3(-80., -15, -40),	//Point A
							  glm::vec3(80., -15, -40),		//Point B
							  glm::vec3(80., -15, -400),	//Point C
							  glm::vec3(-80., -15, -400));	//Point D
	plane->setSpecularity(false);			//Disable specularity of floor
	sceneObjects.push_back(plane);			//Add plane to scene objects
    
    //sphere with pattern
    Sphere *sphere5 = new Sphere(glm::vec3(-20.0, 17.0, -140.0), 6.0);
	sceneObjects.push_back(sphere5);		 //Add sphere to scene objects
    
    //sphere to be textured
    Sphere *sphere6 = new Sphere(glm::vec3(0.0, 22.0, -140.0), 6.0);
	sceneObjects.push_back(sphere6);		 //Add sphere to scene objects
	
	//cube
    glm::vec3 cubeA = glm::vec3(15., -15, -90);
    glm::vec3 cubeB = glm::vec3(15., -5, -90);
    glm::vec3 cubeC = glm::vec3(22.5, -5, -105.);
    glm::vec3 cubeD = glm::vec3(22.5, -15, -105.);
    glm::vec3 cubeE = glm::vec3(15., -15, -120);
    glm::vec3 cubeF = glm::vec3(15., -5, -120);
	glm::vec3 cubeG = glm::vec3(7.5, -5, -105.); 
	glm::vec3 cubeH = glm::vec3(7.5, -15, -105.);
    
    Plane *cubeBottom = new Plane(cubeH, cubeA, cubeD, cubeE);
    Plane *cubeTop = new Plane(cubeG, cubeB, cubeC, cubeF);
    Plane *cubeLeft = new Plane(cubeA, cubeB, cubeG, cubeH);
    Plane *cubeRight = new Plane(cubeE, cubeF, cubeC, cubeD);
    Plane *cubeFront = new Plane(cubeA, cubeB, cubeC, cubeD);
    Plane *cubeBack = new Plane(cubeE, cubeF, cubeG, cubeH);
    
	sceneObjects.push_back(cubeBottom);
    sceneObjects.push_back(cubeTop);
    sceneObjects.push_back(cubeLeft);
    sceneObjects.push_back(cubeRight);
    sceneObjects.push_back(cubeFront);
    sceneObjects.push_back(cubeBack);
    
    //cylinder
	Cylinder *cylinder = new Cylinder(glm::vec3(-15.0, -15.0, -95.0), 4, 5);
    cylinder->setReflectivity(true, 0.3);
    sceneObjects.push_back(cylinder);
    
    //cone
    Cone *cone = new Cone(glm::vec3(-5.0, -15.0, -70.0), 3, 6);
    sceneObjects.push_back(cone);
}


int main(int argc, char *argv[]) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB );
    glutInitWindowSize(500, 500);
    glutInitWindowPosition(20, 20);
    glutCreateWindow("Assignment 2");

    glutDisplayFunc(display);
    initialize();

    glutMainLoop();
    return 0;
}



#ifndef H_TRIANGLE
#define H_TRIANGLE

#include <glm/glm.hpp>
#include "SceneObject.h"

class Triangle : public SceneObject
{
private:
    glm::vec3 a_ = glm::vec3(0);
    glm::vec3 b_ = glm::vec3(0);
    glm::vec3 c_ = glm::vec3(0);      //The 3 vertices of a triangle
	int nverts_ = 3;

public:		
	Triangle() = default;
	
    Triangle(glm::vec3 pa, glm::vec3 pb, glm::vec3 pc) :
		a_(pa), b_(pb), c_(pc), nverts_(3) {}
		
	bool checkSide(glm::vec3 p1, glm::vec3 p2, glm::vec3 az, glm::vec3 bz);
	
	bool isInside(glm::vec3 pos);
	
	float intersect(glm::vec3 pos, glm::vec3 dir);
	
	glm::vec3 normal(glm::vec3 pos);

};

#endif //!H_PLANE


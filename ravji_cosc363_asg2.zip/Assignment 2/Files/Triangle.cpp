

#include "Triangle.h"
#include <vector>
#include "Plane.h"
#include <math.h>

bool Triangle::checkSide(glm::vec3 p1, glm::vec3 p2, glm::vec3 az, glm::vec3 bz)
{
	glm::vec3 ba = bz-az;
	glm::vec3 p1a = p1-az;
	glm::vec3 p2a = p2-az;
	glm::vec3 cp1 = ba.cross(p1a);
	glm::vec3 cp2 = ba.cross(p2a);
	if (cp1.dot(cp2) >= 0){
		return true;
	}
	return false;
}

bool Triangle::isInside(glm::vec3 q)
{
	if (checkSide(q,a,b,c) && checkSide(q,b,a,c) && checkSide(q,c,a,b)){
		return true;
	}
	return false;
}

float Triangle::intersect(glm::vec3 pos, glm::vec3 dir)
{
	glm::vec3 n = normal(pos);
	glm::vec3 vdif = a-pos;
	float vdotn = dir.dot(n);
	if(fabs(vdotn) < 1.e-4) return -1;
    float t = vdif.dot(n)/vdotn;
	if(fabs(t) < 0.0001) return -1;
	glm::vec3 q = pos + dir*t;
	if(isInside(q)) return t;
    else return -1;
}

glm::vec3 Triangle::normal(glm::vec3 p)
{
	glm::vec3 v1 = b_-a_;
	glm::vec3 v2 = c_-a_;
	glm::vec3 n = glm::cross(v1, v2);
	n = glm::normalize(n);
	return n;
}




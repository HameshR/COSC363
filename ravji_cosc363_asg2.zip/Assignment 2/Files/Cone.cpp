/*----------------------------------------------------------
* COSC363  Ray Tracer
*
*  The Cone class
*  This is a subclass of Object, and hence implements the
*  methods intersect() and normal().
-------------------------------------------------------------*/

#include "Cone.h"
#include <math.h>

/**
* Cone's intersection method.  The input is a ray (p0, dir).
*/
float Cone::intersect(glm::vec3 p0, glm::vec3 dir)
{
    // initialise variables in order to calculate values for t
    float vx = p0.x - center.x;
    float vz = p0.z - center.z;
    float vd = height - p0.y + center.y;
    float tan = (radius / height) * (radius / height);

    float a = dir.x * dir.x + dir.z * dir.z - (tan*(dir.y * dir.y));
    float b = 2 * (dir.x * vx + dir.z * vz + tan * vd * dir.y);
    float c = vx * vx + vz * vz - tan * vd * vd;
    float delta = b * b - 4 * a * c;

    if(fabs(delta) < 0.001) return -1.0;
    if(delta < 0.0) return -1.0;

    // calculate values for t
    float t1 = (-b - sqrt(delta))/(2*a);
    float t2 = (-b + sqrt(delta))/(2*a);
    float t;

    if (t1>t2) t = t2;
    else t = t1;
    float r = p0.y + t*dir.y;
    if (center.y < r && r < (height + center.y)) return t;
    else return -1.0; // Cannot find intersection
}


/**
* Returns the unit normal vector at a given point.
* Assumption: The input point p lies on the cone.
*/
glm::vec3 Cone::normal(glm::vec3 p)
{
    float r = sqrt((p.x-center.x)*(p.x-center.x) + (p.z-center.z)*(p.z-center.z));
    glm::vec3 n = glm::vec3(p.x-center.x, r*(radius/height), p.z-center.z);
    n = glm::normalize(n);
    return n;
}

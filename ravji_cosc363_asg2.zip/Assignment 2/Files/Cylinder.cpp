/*----------------------------------------------------------
* COSC363  Ray Tracer
*
*  The Cylinder class
*  This is a subclass of Object, and hence implements the
*  methods intersect() and normal().
-------------------------------------------------------------*/

#include "Cylinder.h"
#include <math.h>

/**
* Cylinder's intersection method.  The input is a ray (p0, dir). 
*/
float Cylinder::intersect(glm::vec3 p0, glm::vec3 dir)
{
    // initialise variables in order to calculate values for t
	float vx = p0.x - center.x;
	float vz = p0.z - center.z;
	
	float a = dir.x * dir.x + dir.z * dir.z;
	float b = 2 * (dir.x * vx + dir.z * vz);
	float c = vx * vx + vz * vz - radius * radius;
	float delta = b * b - 4 * a * c;
	
	if(fabs(delta) < 0.001) return -1.0; 
    if(delta < 0.0) return -1.0;

    // calculate values for t
    float t1 = (-b - sqrt(delta)) / (2 * a);
    float t2 = (-b + sqrt(delta)) / (2 * a);
    float t;
    
    if (fabs(t1) < 0.001)
    {
        if (t2 > 0) t = t2;
        else t1 = -1.0;
    }
    if (fabs(t2) < 0.001) t2 = -1.0;
    
    t = fmin(t1, t2);
    float s = fmax(t1, t2);
    
    float p1 = p0.y + dir.y * t;
    float p2 = p0.y + dir.y * s;
    
    float top1 = (center.y + height - p0.y) / dir.y;
    float top2 = (center.y - p0.y) / dir.y;

    if (center.y < p1 && p1 < (height + center.y)) return t;
    
    else if (center.y < p2 && p2 < (height + center.y) && p1 > (center.y + height)) return top1;
	else if (center.y < p2 && p2 < (height + center.y) && p1 < center.y) return top2;
	else return -1.0; // Cannot find intersection
}

/**
* Returns the unit normal vector at a given point.
* Assumption: The input point p lies on the cylinder.
*/
glm::vec3 Cylinder::normal(glm::vec3 p)
{
	glm::vec3 n = glm::vec3 (p.x - center.x, 0, p.z - center.z);
    n = glm::normalize(n);
    return n;
}
